window.onload = function init() {

    var btn = document.getElementById("get_submit_p");

    btn.onclick = function() {
        alert("post submit success");

    }























    function changepic() {
        var reads = new FileReader();

        f = document.getElementById("file").files[0];

        reads.readAsDataURL(f);

        reads.onload = function (e) {
            document.getElementById("show").src = this.result;
            document.getElementById("show").style.width = "100%";
            document.getElementById("show").style.position = "absolute";
        }
    }//emd funtion changepic

    


}
   