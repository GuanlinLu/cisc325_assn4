# 325Assignment4

v1.0 updates 
1. homepage search bar now supports direct to different search result pages by entering different input 
For now it only supports cisc365 and cisc220 and the 220 page is not built yet, but I will fix it tonight.
2.sell page fake submitment impletmented by alert () 
// I think the market page update could also be impletmented without real back end but pure js, I might need a little bit more time for this.
3. review page update with new UI and review function ( I would add more detail for the input optional or not )
4.reorganize the dir for pages and files. 



