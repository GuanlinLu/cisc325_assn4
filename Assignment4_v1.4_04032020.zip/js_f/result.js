window.onload = function init() {
	var btn365 = document.getElementById("go_365");
	var btn220 = document.getElementById("go_220");
	var btn324 = document.getElementById("go_324");
	
	btn365.onclick = function(){
		location.href = "bookinfo.html";
	}
	
	btn220.onclick = function(){
		location.href ="bookinfo2.html";
	}
	
	btn324.onclick = function() {
		location.href = "bookinfo3.html";
	}
	
	}