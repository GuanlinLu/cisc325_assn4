﻿/**window.onload = function init() {
    var btn = document.getElementById("get_submit");
   
    btn.onclick = function direct () {
		var search = document.getElementById("get_Search").value;
		var course1 = "cisc365";
		var course2 = "cisc220";
		
         if (search.localeCompare(course1) == 0  {
            location.href = "bookinfo.html";
        }
         else if (search.localeCompare(course2) == 0) {
            location.href = "bookinfo2.html";
        } else {
            location.href = "resultcisc.html";
        }

    }
}
**/

window.onload = function init() {
    var btn = document.getElementById("get_submit");
    var course1 = "cisc365";
    var course2 = "cisc220";
	var course3 = "cisc324";
	var text_n1 = "Introduction to Algorithms";
	var text_n2 = "c programming language";
	var subject  = "cisc";
    btn.onclick = function direct () {
         var search = document.getElementById("get_Search").value;
         if (search.localeCompare(course1) == 0 || search.localeCompare(text_n1) == 0 ) {
            location.href = "bookinfo.html";
        }
         else if (search.localeCompare(course2) == 0 ||search.localeCompare(text_n2) == 0 ) {
            location.href = "bookinfo2.html";
        } else if(search.localeCompare(course3) == 0){
			location.href = "bookinfo3.html"
		} else if (search.localeCompare(subject) == 0){
            location.href = "resultcisc.html";
        }else{
			location.href = "noresult.html";
		}

    }
}
